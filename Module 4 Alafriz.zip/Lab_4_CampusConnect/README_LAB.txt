Lab 4 - CampusConnect project based on uploaded CampusConnect.
Open CampusConnect.xcodeproj in Xcode.
Lab 2: navigation and input. Lab 3: announcements and custom cells. Lab 4: UserDefaults and Core Data.
Xcode/macOS simulator build not available in this environment; please build and run on a Mac.
