import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var messageLabel: UILabel!
    var studentName: String = ""
    var notificationsEnabled: Bool = false
    var selectedRole: String = ""
    var announcement: CampusAnnouncement?

    override func viewDidLoad() {
        super.viewDidLoad()
        if let announcement = announcement {
            title = announcement.category
            messageLabel.text = "\(announcement.title)\n\(announcement.date)"
        } else {
            title = "Campus Events"
            let status = notificationsEnabled ? "on" : "off"
            messageLabel.text = "Welcome, \(studentName)! (\(selectedRole)) Notifications: \(status)."
        }
    }
}
