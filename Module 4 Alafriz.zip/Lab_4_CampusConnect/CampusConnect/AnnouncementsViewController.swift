import UIKit
import CoreData
class AnnouncementsViewController: UITableViewController {
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    private var announcements: [CampusAnnouncement] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 90
        seedInitialAnnouncementsIfNeeded()
        loadAnnouncements()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return announcements.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AnnouncementCell", for: indexPath) as? AnnouncementCell else { return UITableViewCell() }
        cell.configure(with: announcements[indexPath.row])
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "ShowAnnouncementDetailSegue", sender: announcements[indexPath.row])
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ShowAnnouncementDetailSegue",
           let destination = segue.destination as? DetailViewController,
           let selected = sender as? CampusAnnouncement {
            destination.announcement = selected
        }
    }

    private func seedInitialAnnouncementsIfNeeded() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        guard let count = try? context.count(for: request), count == 0 else { return }
        let entries: [(String, String, String)] = [
            ("Enrollment Period Extended", "Aug 03, 2026", "Registrar"),
            ("Library Hours Extended", "Aug 05, 2026", "Library"),
            ("Career Fair 2026", "Aug 10, 2026", "Career Center"),
            ("Student Council Elections", "Aug 14, 2026", "Student Affairs"),
            ("WI-FI Maintenance Notice", "Aug 16, 2026", "IT Services"),
            ("Midterm Exam", "Oct 5, 2026", "Higher Education Office")
        ]
        for (title, date, category) in entries {
            let entry = CampusAnnouncement(context: context)
            entry.title = title
            entry.date = date
            entry.category = category
        }
        do { try context.save() } catch { print("Seed failed: \(error)") }
    }

    private func loadAnnouncements() {
        let request: NSFetchRequest<CampusAnnouncement> = CampusAnnouncement.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true)]
        do { announcements = try context.fetch(request) }
        catch { print("Fetch failed: \(error)"); announcements = [] }
        tableView.reloadData()
    }

    @IBAction func addAnnouncementTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "New Announcement", message: "Enter a title and category.", preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Title" }
        alert.addTextField { $0.placeholder = "Category" }
        alert.addAction(UIAlertAction(title: "Save", style: .default) { [weak self, weak alert] _ in
            guard let self = self,
                  let title = alert?.textFields?[0].text?.trimmingCharacters(in: .whitespacesAndNewlines), !title.isEmpty,
                  let category = alert?.textFields?[1].text?.trimmingCharacters(in: .whitespacesAndNewlines), !category.isEmpty else { return }
            let entry = CampusAnnouncement(context: self.context)
            entry.title = title
            entry.category = category
            entry.date = DateFormatter.localizedString(from: Date(), dateStyle: .long, timeStyle: .none)
            do { try self.context.save(); self.loadAnnouncements() }
            catch { self.context.rollback(); print("Save failed: \(error)") }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }
}
